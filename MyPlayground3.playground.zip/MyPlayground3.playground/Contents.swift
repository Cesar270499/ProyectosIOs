import UIKit

//Declarar 4 variables con 3 tipos de datos


//Enteros
var numero  : Int = 13
//Decimales Foltantes
var otronumero : Float = 13.8
//String
let String = "Hello, playground"


//Asosiacion dato String

let otroString = "Esto es una Prueba "
//Asociacion dato Entero
var punto1 = (1,3)
print ("El punto es \(punto1)")

var punto2 = ( x:1, y:3)
print ("El punto es \(punto2)")


//Array

var numeros : Array <Int> = Array <Int>()
numeros.append(1)
numeros.append(3)
numeros.count

//Diccionario
var directorio :Dictionary<String, Int> =
Dictionary<String, Int>()
directorio = ["TOL": 1]
directorio = ["CDMX": 3]
print("Diccionario: \(directorio)")
