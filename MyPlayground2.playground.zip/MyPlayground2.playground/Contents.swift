import UIKit

var str = "Hello, playground"
var nombre = "Cesar Rossano Nava"
