//
//  ContentView.swift
//  Actividad8
//
//  Created by user182872 on 3/25/21.
//  Copyright © 2021 user182872. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Text("Hello, World!")
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
