//
//  ViewController.swift
//  Actividad10
//
//  Created by user182872 on 4/20/21.
//  Copyright © 2021 CesarRN. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var nombres: UITableView!
    
    var nombre = ["Carlos","Luis","Pedro","Jose"]
        
    override func viewDidLoad() {
        super.viewDidLoad()
        
        nombres.delegate = self
        nombres.dataSource = self
    }


}

extension ViewController : UITableViewDelegate, UITableViewDataSource {
    func tableView (_ tableView: UITableView, didSelectRowAt indexPath  : IndexPath){
        print("You selected\(nombre[indexPath.row])")
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return nombre.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = nombres.dequeueReusableCell(withIdentifier: "celdadenombres", for: indexPath)
        cell.textLabel?.text = nombre[indexPath.row]
        return cell
    }
}
