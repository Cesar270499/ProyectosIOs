import UIKit

var str = "Actividad 4"

//Declarar variable datos con valores (3, 6, 9, 2, 4, 1) y encontrar varoables menores a 5
let array  = 3; 6; 9; 2; 4;
print ("Encontrar valores menores a 5")
for i in datos

//Hacer suma de 2 variables
func suma (a:Int, b:Int)

// Funcion numero de mes

enum meses {
    case Enero
    case Fe
}
var n = 4
switch mes {
    case 1:
    print ("Enero es el mes: 1")
    case 2:
    print ("Febrero es el mes: 2")
    case 3:
    print ("Marzo es el mes: 3")
    case .marzo :
    print ("Abril es el mes: 4")
    case .enero :
    print ("Mayo es el mes: 5")
    case .enero :
    print ("Junio es el mes: 6")
    case .enero :
    print ("Julio es el mes: 7")
    case .enero :
    print ("Agosto es el mes: 8")
    case .enero :
    print ("Septiembre es el mes: 9")
    case .enero :
    print ("Octubre es el mes: 10")
    case .enero :
    print ("Noviembre es el mes: 11")
    case .enero :
    print ("Diciembre es el mes: 12")
}

